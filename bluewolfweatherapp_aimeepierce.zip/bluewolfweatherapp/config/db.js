
module.exports = {
        url : 'mongodb://aimee_pierce:bluewolf1@ds121099.mlab.com:21099/bluewolf_weather'
    }
